#include <stdio.h>

int main() {
    int pilihan;
    float massa, kecepatan, ketinggian, gravitasi = 9.8; // Asumsikan gravitasi bumi

    printf("Program Menghitung Energi\n");
    printf("Pilih jenis energi yang ingin dihitung:\n");
    printf("1. Energi Potensial\n");
    printf("2. Energi Kinetik\n");
    printf("3. Energi Mekanik\n");
    printf("Masukkan pilihan Anda: ");
    scanf("%d", &pilihan);

    switch (pilihan) {
        case 1:
            printf("Masukkan massa benda (kg): ");
            scanf("%f", &massa);
            printf("Masukkan ketinggian benda (m): ");
            scanf("%f", &ketinggian);

            float energiPotensial = massa * gravitasi * ketinggian;
            printf("Energi Potensial = %.2f Joule\n", energiPotensial);
            break;

        case 2:
            printf("Masukkan massa benda (kg): ");
            scanf("%f", &massa);
            printf("Masukkan kecepatan benda (m/s): ");
            scanf("%f", &kecepatan);

            float energiKinetik = 0.5 * massa * kecepatan * kecepatan;
            printf("Energi Kinetik = %.2f Joule\n", energiKinetik);
            break;

        case 3:
            printf("Masukkan massa benda (kg): ");
            scanf("%f", &massa);
            printf("Masukkan ketinggian benda (m): ");
            scanf("%f", &ketinggian);
            printf("Masukkan kecepatan benda (m/s): ");
            scanf("%f", &kecepatan);

            energiPotensial = massa * gravitasi * ketinggian;
            energiKinetik = 0.5 * massa * kecepatan * kecepatan;
            float energiMekanik = energiPotensial + energiKinetik;
            printf("Energi Mekanik = %.2f Joule\n", energiMekanik);
            break;

        default:
            printf("Pilihan tidak valid.\n");
    }

    return 0;
}
